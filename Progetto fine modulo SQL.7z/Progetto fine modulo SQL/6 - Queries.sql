-- query n1: analisi fatturato per prodotto nell'anno corrente
-- query n2: analisi quantit� vendute per categoria
-- query n3: analisi fatturato per provincia indicando anche lo stato
-- query n4: analisi fatturato per et� cliente (anno di nascita)
-- query n5: analisi fornitori pi� popolari
-- query n6: analisi fornitori con piu prodotti non venduti
-- query n7: analisi quantita clienti per area geografica (Provincia)
-- query n8: analisi fatturato e quantita ordini per cliente
-- query n9: analisi fatturato e quantit� ordini per mese
-- query n10: supponendo che in Categoria ci siano (IDCategoria=1, Nome=Sigaretta Elettronica) e (IDCategoria=2 , Nome=Liquidi)
--			  analizzo quanti clienti usano il sito solo per comprare liquidi e possiedono quindi gia una sigaretta elettronica


-- query n1: analisi fatturato per prodotto nell'anno corrente
create view EL_vVenditePerProdottoAnnoCorrente  as(
	select 
		p.IDProdotto as IDProdotto,
		p.NomeProdotto as NomeProdotto,
		sum(v.Importo) as FatturatoTotale
	from 
		Prodotto as P
		left join --voglio ottenere anche i prodotti che non sono stati venduti
		RigaVendita as V
		on p.IDProdotto = v.IDProdotto
		left join --voglio ottenere la data dalla testata d'ordine
		TestataVendita as T
		on v.IDOrdine= T.IDOrdine
	where year(T.DataOrdine)=year(getdate())
	group by p.IDProdotto, p.NomeProdotto
)

-- query n2: analisi quantit� vendute per categoria
create view EL_vQuantitaVendutePerCategoria as(
	select 
		c.IDCategoria as IDCategoria,
		c.NomeCategoria  as NomeCategoria,
		sum(v.Quantit�) as ConteggioTransazioni
	from
		RigaVendita as v
		inner join --inserisco le informazioni sui prodotti nella tabelle delle vendite (left � indifferente essendo ogni riga di vendita sempre associata ad un prodotto)
		Prodotto as p
		on v.IDProdotto= p.IDProdotto
		inner join --risalgo al nome delle categorie tramite la tabella Categoria (left � indifferente essendo ogni prodotto sempre associata ad una categoria)
		Categoria as c
		on c.IDCategoria = p.IDCategoria
	group by c.IDCategoria, c.NomeCategoria
)

-- query n3: analisi fatturato per provincia indicando anche lo stato
create view EL_vFatturatoPerArea as(
	select 
		g.Stato as Stato,
		g.Provincia as Provincia,
		sum(rv.Importo) as ImportoTotale

	from
		TestataVendita as tv
		inner join -- unisco le informazio di testata (contengono i clienti) a quelle di riga (contengono i prodotti)
		RigaVendita as rv
		on tv.IDOrdine = rv.IDOrdine
		inner join --risalgo alle informazioni sui clienti che effettuano acquisti (left indifferente)
		Cliente as c
		on tv.IDCliente = c.IDCliente
		inner join --risalgo alle informazioni sulle aree geografiche dei vari clienti
		AreaGeografica as g
		on c.IDArea = g.IDArea
	group by
		g.Stato,
		g.Provincia
)

-- query n4: analisi fatturato per et� cliente (anno di nascita)
create view EL_vFatturatoPerEt� as(
	select 
		c.IDCliente as IDCliente,
		concat(c.Nome, ' ', c.Cognome) as NomeCliente,
		year(c.DataDiNascita) as AnnoDiNascita,
		sum(rv.Importo) as TotaleSpese
	from
		TestataVendita as tv
		inner join -- unisco le informazio di testata (contengono i clienti) a quelle di riga (contengono i prodotti)
		RigaVendita as rv
		on tv.IDOrdine = rv.IDOrdine
		inner join --risalgo alle informazioni sui clienti che effettuano acquisti (left indifferente)
		Cliente as c
		on tv.IDCliente = c.IDCliente
	group by 
		c.IDCliente,
		concat(c.Nome, ' ', c.Cognome),
		c.DataDiNascita
)

-- query n5: analisi fornitori pi� popolar
create view EL_vTop10Fornitori as(
	select top 10 
		f.IDFornitore as IDFornitore,
		f.NomeFornitore as NomeFornitore,
		sum(v.Importo) as FatturatoProdottiFornitore
	from
		Fornitore as f
		inner join 
		Prodotto as p
		on f.IDFornitore = p.IDFornitore
		inner join --non mi interessano i prodotti non venduti
		RigaVendita as v
		on p.IDProdotto = v.IDProdotto
	group by 
		f.IDFornitore,
		f.NomeFornitore
	order by
		sum(v.Importo) desc
)

-- query n6: analisi fornitori con piu prodotti non venduti
create view EL_FornitoriConPiuProdottiNonVenduti as(
	select
		f.IDFornitore as IDFornitore,
		f.NomeFornitore as NomeFornitore,
		count(p.IDProdotto) as ConteggioProdottiMaiVenduti
	from
		Fornitore as f
		inner join
		Prodotto as p
		on f.IDFornitore = p.IDFornitore
		left join --includo i prodotti non venduti
		RigaVendita as v
		on p.IDProdotto = v.IDProdotto
	where 
		v.IDProdotto is null --condizione (anti) per escludere tutti i prodotti venduti
	group by
		f.IDFornitore,
		f.NomeFornitore
	order by
		count(p.IDProdotto) desc
)

-- query n7: analisi quantita clienti per area geografica (Provincia)

create view EL_vClientiPerProvincia as(
	select
		g.Stato as Stato,
		g.Provincia as Provincia,
		count(c.IDCliente) as NumeroClienti
	from
		Cliente as c
		inner join
		AreaGeografica as g
		on c.IDArea = g.IDArea
	group by 
		g.Stato,
		g.Provincia
)

-- query n8: analisi fatturato e quantita ordini per cliente
create view EL_vFatturatoeOrdiniPerCliente as(
	select
		c.IDCliente as IDCliente,
		concat(c.Nome, ' ', c.Cognome) as NomeCliente,
		sum(rv.Quantit�) as Quantit�Vendute,
		sum(rv.Importo) as ImportoTotale
	from
		Cliente as c
		left join --ottengo anche i clienti che non hanno mai comprato
		TestataVendita as tv
		on c.IDCliente = tv.IDCliente
		left join
		RigaVendita as rv
		on tv.IDOrdine = rv.IDOrdine
	group by 
		c.IDCliente,
		concat(c.Nome, ' ', c.Cognome)
)


-- query n9: analisi fatturato e quantit� ordini per mese
create view EL_vFatturatoeOrdiniPerMese as(
	select
		year(tv.DataOrdine) as Anno,
		month(tv.DataOrdine) as Mese,
		sum(rv.Quantit�) as Quantit�Vendute,
		sum(rv.Importo) as ImportoTotale
	from
		TestataVendita as tv
		left join
		RigaVendita as rv
		on tv.IDOrdine = rv.IDOrdine
	group by
		year(tv.DataOrdine),
		month(tv.DataOrdine)
)

-- query n10: supponendo che in Categoria ci siano (IDCategoria=1, Nome=Sigaretta Elettronica) e (IDCategoria=2 , Nome=Liquidi)
--			  analizzo quanti clienti usano il sito solo per comprare liquidi e possiedono quindi gia una sigaretta elettronica
create view EL_vClientiSoloLiquidi as(
	select
		IDCliente as IDCliente,
		concat(Nome, ' ', Cognome) as Nome
	from
		Cliente
	where 
		Cliente.IDCliente not in(  --creo la mia sorgente che contiene solo gli idCliente dei soli clienti che comprano solo liquidi
			select distinct tv.IDCliente
			from
				TestataVendita as tv
				inner join
				RigaVendita as rv
				on tv.IDOrdine = rv.IDOrdine
				inner join
				Prodotto as p
				on rv.IDProdotto = p.IDProdotto
			--ho ottenuto una tabelle che contiene tutte le informazioni sugli ordini, su cosa � stato venduto in essi e in che categoria sono questi prodotti venduti
			where p.IDCategoria = 2 -- 2 corrisponde ai liquidi
		)
)