create table AreaGeografica(
	IDArea int not null,
	Stato varchar (20) not null,
	Regione varchar (20) not null, 
	Provincia varchar (20) not null, 
	Comune varchar (20) not null, 
	Indirizzo varchar (20) not null,
	constraint PK_AreaGeografica primary key (IDArea))

create table Categoria(
	IDCategoria int not null,
	NomeCategoria varchar(20) not null,
	constraint PK_Categoria primary key (IDCategoria))

create table Fornitore(
	IDFornitore int not null,
	NomeFornitore varchar(20) not null, 
	IDArea int null,
	constraint PK_Fornitore primary key (IDFornitore),
	constraint FK_AreaGeograficaFornitore foreign key (IDArea)
		references AreaGeografica(IDArea))

create table Prodotto (
	IDProdotto int not null,
	NomeProdotto varchar(20) null,
	PrezzoAcquisto dec null,
	MoltiplicatorePrezzoVendita dec not null,
	IDCategoria int null,
	IDFornitore int not null,
	constraint PK_Prodotto primary key (IDProdotto),
	constraint FK_Categoria foreign key (IDCategoria)
		references Categoria(IDCategoria),
	constraint FK_FornitoreProdotto foreign key (IDFornitore)
		references Fornitore(IDFornitore))

create table Magazzino(
	IDScaffale int not null,
	IDCassetto int not null,
	IDProdotto int null,
	Quantit� int null,
	MinimoPerRiordino int not null,
	constraint PK_Magazzino primary key (IDScaffale, IDCassetto),
	constraint FK_Prodotto foreign key (IDProdotto)
		references Prodotto(IDProdotto))

create table Cliente(
	IDCliente int not null,
	CodiceFiscale varchar(16) not null,
	NCartaIdentit� varchar(9) not null, 
	Nome varchar(20) null, 
	Cognome varchar(20) null, 
	DataDiNascita date null, 
	DataRegistrazione date not null, 
	IDArea int null,
	constraint PK_Cliente primary key (IDCliente),
	constraint FK_AreaGeograficaCliente foreign key (IDArea)
		references AreaGeografica(IDArea))

create table TestataVendita(
	IDOrdine int not null, 
	IDCliente int not null, 
	DataOrdine date not null, 
	FlagConsegnato bit not null,
	constraint PK_TestataVendita primary key (IDOrdine),
	constraint FK_Cliente foreign key (IDCliente)
		references Cliente(IDCliente))

create table RigaVendita(
	IDOrdine int not null,
	RigaOrdine int not null,
	IDProdotto int not null,
	Quantit� int not null,
	Importo dec not null,
	Sconto dec not null,
	PercTasse dec not null,
	FlagConsegnato bit not null,
	constraint PK_RigaVendita primary key (IDOrdine, RigaOrdine),
	constraint FK_TestataVedinta foreign key (IDOrdine)
		references TestataVendita(IDOrdine),
	constraint FK_ProdottoVendita foreign key (IDProdotto)
		references Prodotto(IDProdotto))

create table TestataAcquisto(
	IDOrdine int not null, 
	IDFornitore int not null, 
	DataOrdine date not null, 
	FlagConsegnato bit not null,
	constraint PK_TestataAcquisto primary key (IDOrdine),
	constraint FK_FornitoreAcquisto foreign key (IDFornitore)
		references Fornitore(IDFornitore))

create table RigaAcquisto(
	IDOrdine int not null,
	RigaOrdine int not null,
	IDProdotto int not null,
	Quantit� int not null,
	Importo dec not null,
	Sconto dec not null,
	PercTasse dec not null,
	FlagConsegnato bit not null,
	constraint PK_RigaAcquisto primary key (IDOrdine, RigaOrdine),
	constraint FK_TestataAcquisto foreign key (IDOrdine)
		references TestataAcquisto(IDOrdine),
	constraint FK_ProdottoAcquisto foreign key (IDProdotto)
		references Prodotto(IDProdotto))

	